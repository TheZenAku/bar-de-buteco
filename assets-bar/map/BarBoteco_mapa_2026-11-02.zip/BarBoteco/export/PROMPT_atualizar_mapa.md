# Tarefa: atualizar o mapa do jogo (export de 02/11/2026: texturas Poliigon, carrinho de espeto, guarda-corpo, geladeira)

Você está na VM do servidor do jogo "bar-de-buteco" (Highland Bar). Exportei de novo o mapa do Blender e preciso que a versão nova entre no jogo, do jeito que os jogadores acessam.

## Onde estão os arquivos

A pasta do pipeline fica em `C:\Users\MuOnline\Desktop\BAR\bar-de-buteco\assets-bar\map\BarBoteco`. Acabei de colar por cima dela a versão nova, com a mesma estrutura de pastas. Se não estiver aí, procure por `bar_boteco.glb` com data de 02/11/2026.

Arquivos do mapa (dentro de `export\`):

| Arquivo | O que é |
|---|---|
| `bar_boteco.glb` (26,1 MB) | bar + bairro original, sempre carregado (texturas embutidas) |
| `bar_boteco_draco.glb` (9,2 MB) | o mesmo com Draco (precisa de DRACOLoader) |
| `bar_boteco_colisao.glb` | caixas `COL_*` (escala = tamanho) + pivôs das portas `COLPORTA_*` |
| `cidade\setores\cidade_Sxx_yy.gltf/.bin`, `_lod.gltf/.bin`, `_colisao.glb` | 64 setores de 100 m (visual, LOD, colisão) |
| `cidade\texturas\` | texturas compartilhadas pelos setores. Os `.gltf` apontam para `../texturas/` |
| `cidade\cidade_anel.gltf`, `cidade\cidade_distante.gltf` | cenário externo (sem colisão) |
| `cidade\cidade_setores.json` | manifesto: limites, arquivos, tamanhos e vizinhos de cada setor |
| `cidade\cidade_vias.json`, `cidade\cidade_lotes.json`, `cidade\pontos_ifood.json` | grafo de ruas, lotes e pontos iFood (sem mudança) |

Não edite os GLB/glTF nem renomeie nós: o jogo acha mesas, portas, luzes, interativos e marcadores pelo nome.

## O que mudou desde a última cópia (01/11, versão "b")

1. **Texturas novas (Poliigon).** Todas as texturas de superfície do bar foram trocadas por texturas da Poliigon: tijolo, reboco, concreto, cimento queimado, madeiras, forro, azulejo, piso cerâmico, granito, inox, metal preto, metal ondulado, feltro da sinuca, tapete e tecido do palco, plásticos, grama, terra e asfalto.
   - Os nomes dos materiais não mudaram (`Tijolo`, `Reboco_*`, `Concreto`, `Madeira`, `Pol_Inox` etc.); só a imagem e a escala da UV mudaram.
   - No `bar_boteco.glb` as texturas vão embutidas. Por isso ele cresceu: 21,7 → 26,1 MB (Draco 6,4 → 9,2 MB).
   - A cidade divide vários desses materiais (concreto, reboco, asfalto, grama, metal ondulado), então os setores também mudaram. As imagens novas são os `pol_*.jpg` em `cidade\texturas\`. **Publique a pasta `cidade\texturas\` inteira junto com os setores**, senão os setores dão 404 de textura. As texturas antigas que sobraram na pasta (`concreto.jpg`, `reboco.jpg`, `asfalto.jpg` etc.) podem ficar; alguns setores ainda usam algumas delas.
2. **Carrinho de espeto refeito** (nó `Carrinho_Espeto`, coleção de interativos, mesmo lugar na calçada): agora é um carrinho de espetinho com gabinete de inox, placa "ESPETINHO / HIGHLAND BAR", churrasqueira com carvão em brasa e espetos, rodas e alça.
   - O nome do nó e o extra `interativo = "carrinho_espeto"` são os mesmos. Os filhos `Carrinho_Espeto_FX_Fogo`, `Carrinho_Espeto_FX_Fumaca` e `Carrinho_Espeto_FX_Brasas` continuam com os mesmos nomes, mas **mudaram de posição**: o carrinho novo tem 1,0 m de altura (o antigo tinha 1,9 m, com chaminé), então a fumaça sai agora da grelha (~1,04 m) e não do alto da chaminé. Se o código do jogo tem posições do fogo/fumaça fixas no código em vez de ler os filhos, ajuste para ler os filhos.
   - A caixa `COL_Int_Carrinho_Espeto` foi refeita com o tamanho novo (0,99 x 0,68 x 1,00 m).
3. **Guarda-corpo da varanda refeito** (`Varanda_GuardaCorpo`, fundido na mobília): saiu o gradil branco liso; agora são montantes e barras de metal preto fosco com corrimão de madeira. Mesmos vãos e mesma altura; as caixas `COL_Mob_GuardaCorpo*` não mudaram.
4. **Geladeira expositora refeita** (as 4 do bar e do lounge, fundidas em `Bar_Mobilia` como antes): corpo preto com a arte synthwave e o logo Highland Bar nas laterais, letreiro iluminado "CERVEJA GELADA", porta de vidro com neon azul/rosa e o interior iluminado cheio de latas e long necks. Mesmo tamanho, posição e colisão.
   - Materiais novos: `Geladeira_Arte` e `Geladeira_Latas` (com emissive), `Gel_Neon_Ciano`, `Gel_Neon_Rosa`, `Gel_LED`. A porta usa o material `Vidro` (transparente, `alphaMode: BLEND`) que já existia.

## O que fazer

1. **Descubra o que o jogo carrega hoje.** Procure onde ele lê `bar_boteco.glb` (ou a versão Draco), a colisão e a cidade (`cidade_setores.json` / setores). A integração anterior foi em three.js (`export\integracao_highland.js`, função `prepararMapa`). Confirme no código.
2. **Procure o código do carrinho de espeto** (`Carrinho_Espeto`, `carrinho_espeto`, `FX_Fogo`, `FX_Fumaca`, `FX_Brasas`). Confirme que ele lê as posições dos nós filhos; se tiver alturas fixas (como 1,79 m da chaminé antiga), me diga onde estão e ajuste para os filhos.
3. **Faça backup** dos arquivos de mapa que o jogo serve hoje, numa pasta datada, antes de sobrescrever.
4. **Copie os arquivos novos** para onde o jogo os serve. Mantenha `cidade\setores\` e `cidade\texturas\` como pastas irmãs, porque os `.gltf` usam caminho relativo `../texturas/`.
5. **Cache:** se os assets têm cache longo (servidor, CDN ou service worker), troque a versão ou o hash na URL para os jogadores receberem o mapa novo.
6. **Teste:**
   - O jogador nasce em (12; 0,15; 1,6) em glTF. Olhe a fachada e a varanda: tijolo, reboco e piso com as texturas novas, sem nada preto, rosa ou esticado.
   - O guarda-corpo da varanda tem que aparecer preto com corrimão de madeira, e continuar segurando o jogador.
   - Vá até o carrinho de espeto na calçada: o fogo, as brasas e a fumaça têm que sair da grelha, não do ar acima dele. A interação do carrinho tem que continuar funcionando.
   - Entre no bar e olhe as geladeiras: arte nas laterais, letreiro aceso e as latas visíveis através do vidro.
   - Ande um pouco pela cidade: os setores não podem dar 404 de textura.
   - O console não pode mostrar 404 nem erro de extensão glTF.

Pergunte antes só se algo afetar jogadores online, por exemplo reiniciar o serviço em produção. No fim, me diga em poucas linhas o que foi trocado, onde ficou o backup, se o código do carrinho precisou de ajuste e o resultado do teste.
