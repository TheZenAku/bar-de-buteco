# Tarefa: atualizar o mapa do jogo (export de 01/11/2026, com os pontos iFood)

Você está na VM do servidor do jogo "bar-de-buteco" (Highland Bar). Exportei de novo o mapa do Blender e preciso que a versão nova entre no jogo, do jeito que os jogadores acessam.

## Onde estão os arquivos

A pasta do pipeline fica em `C:\Users\MuOnline\Desktop\BAR\bar-de-buteco\assets-bar\map\BarBoteco`. Acabei de colar por cima dela a versão nova, com a mesma estrutura de pastas. Se não estiver aí, procure por `bar_boteco.glb` com data de 01/11/2026.

Arquivos do mapa (dentro de `export\`):

| Arquivo | O que é |
|---|---|
| `bar_boteco.glb` (19 MB) | bar + bairro original, sempre carregado |
| `bar_boteco_draco.glb` (4,6 MB) | o mesmo com Draco (precisa de DRACOLoader) |
| `bar_boteco_colisao.glb` | caixas `COL_*` (escala = tamanho) + pivôs das portas `COLPORTA_*` |
| `cidade\setores\cidade_Sxx_yy.gltf/.bin`, `_lod.gltf/.bin`, `_colisao.glb` | 64 setores de 100 m (visual, LOD, colisão) |
| `cidade\texturas\` | texturas compartilhadas pelos setores. Os `.gltf` apontam para `../texturas/` |
| `cidade\cidade_anel.gltf`, `cidade\cidade_distante.gltf` | cenário externo (sem colisão) |
| `cidade\cidade_setores.json` | manifesto: limites, arquivos, tamanhos e vizinhos de cada setor |
| `cidade\cidade_vias.json`, `cidade\cidade_lotes.json` | grafo de ruas e lotes (IA de trânsito, entregas) |
| `cidade\pontos_ifood.json` | **novo**: os 23 pontos de retirada iFood |
| `cidade\RELATORIO_CIDADE.md` | documentação completa da cidade. Leia a seção "O que ainda falta para integrar ao jogo" |

Não edite os GLB/glTF nem renomeie nós: o jogo acha mesas, portas, luzes e marcadores pelo nome.

## O que mudou desde a última cópia

1. **Pontos de retirada "Highland Bar Delivery" (armário de iFood), 23 no total:**
   - 1 no bairro original, perto do bar. Está no `bar_boteco.glb`, fundido no nó `Mapa_Bairro`, sem nó próprio.
   - 22 espalhados pela cidade, fundidos no `Sxx_yy_Estatico` de 22 setores. Cada ponto acrescenta cerca de 5,3 mil triângulos e 246 KB ao setor.
   - Colisão: caixas `COL_Ponto_iFood*` no `bar_boteco_colisao.glb` e nos `cidade_Sxx_yy_colisao.glb` desses setores.
   - Posição e frente de cada um (coordenadas glTF, Y para cima, em metros) estão em `pontos_ifood.json`. Use esse arquivo se o jogo precisar de pontos de entrega ou de interação.
2. **Quatro texturas novas** em `cidade\texturas\`: `ponto_ifood_atlas.jpg`, `ponto_ifood_escovado.jpg`, `ponto_ifood_pintura.jpg` e `ponto_ifood_pintura_n.jpg`. Elas precisam ser publicadas junto com os setores, senão esses 22 setores dão 404 de textura.
3. **Extras da cena do `bar_boteco.glb`:** saiu a propriedade interna `cid_vis_usuario`, um JSON de uns 60 KB com o estado do editor, que vazava no arquivo. `nevoa`, `camera_far_minimo_m`, `area_jogavel` e `setores` continuam lá.

O resto não mudou: geometria, nomes, materiais, colisores e marcadores são os mesmos da cópia anterior.

## O que fazer

1. **Descubra o que o jogo carrega hoje.** Procure onde ele lê `bar_boteco.glb` (ou a versão Draco) e a colisão, e se a cidade (`cidade_setores.json` / setores) já está integrada. A integração anterior foi em three.js (`export\integracao_highland.js`, função `prepararMapa`). Confirme no código.
2. **Faça backup** dos arquivos de mapa que o jogo serve hoje, numa pasta datada, antes de sobrescrever.
3. **Copie os arquivos novos** para onde o jogo os serve. Mantenha `cidade\setores\` e `cidade\texturas\` como pastas irmãs, porque os `.gltf` usam caminho relativo `../texturas/`.
4. **Cache:** se os assets têm cache longo (servidor, CDN ou service worker), troque a versão ou o hash na URL para os jogadores receberem o mapa novo.
5. **Se a cidade ainda não estiver integrada no jogo:** atualize só o bar (passos 2 a 4). Depois me mostre um plano curto de como integrar o streaming de setores, seguindo o `RELATORIO_CIDADE.md`. Não comece essa integração sem eu aprovar.
6. **Teste:**
   - O jogador nasce em (12; 0,15; 1,6) em glTF. O ponto iFood do bairro fica em (−1,43; 0,15; −14,04), a uns 20 m dali. Ele tem que aparecer, com letreiro e placa iluminados, e bloquear a passagem pela colisão.
   - Se a cidade estiver integrada, vá também até um setor com iFood, por exemplo `S04_05` ou `S04_06`, e confira as texturas.
   - O console não pode mostrar 404.

Pergunte antes só se algo afetar jogadores online, por exemplo reiniciar o serviço em produção. No fim, me diga em poucas linhas o que foi trocado, onde ficou o backup e o resultado do teste.
